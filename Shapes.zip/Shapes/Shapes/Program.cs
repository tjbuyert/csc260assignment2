﻿using System;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            var rectangle1 = new Rectangle();
            var rectangle2 = new Rectangle(3, 4);
            var square1 = new Square();
            var square2 = new Square(4);
            var ellipse1 = new Ellipse();
            var ellipse2 = new Ellipse(4, 5);
            var circle1 = new Circle();
            var circle2 = new Circle(3);
            var pentagon1 = new Pentagon();
            var pentagon2 = new Pentagon(7);
            Console.Write("All done, goodbye.\n");

        }
    }
}
