﻿using System;

namespace Shapes
{
    
    class Program
    { 
        static void Main(string[] args)
        {
            var rectangle1 = new Rectangle();//default constructor
            var rectangle2 = new Rectangle(3, 4);//parameterized constructor
            Console.WriteLine(rectangle2.calculatePerimeter(rectangle2));
            Console.WriteLine(rectangle2.calculateArea(rectangle2));
            var square1 = new Square();//default constructor
            var square2 = new Square(4);//parameterized constructor
            Console.WriteLine(square2.calculatePerimeter(square2));
            Console.WriteLine(square2.calculateArea(square2));
            var ellipse1 = new Ellipse();//default constructor
            var ellipse2 = new Ellipse(4, 5);//parameterized constructor
            Console.WriteLine(ellipse2.CalculatePerimeter(ellipse2));
            Console.WriteLine(ellipse2.CalculateArea(ellipse2));
            var circle1 = new Circle();//default constructor
            var circle2 = new Circle(3);//parameterized constructor
            Console.WriteLine(circle2.calculatePerimeter(circle2));
            Console.WriteLine(circle2.calculateArea(circle2));
            var pentagon1 = new Pentagon(); //default constructor
            var pentagon2 = new Pentagon(7); //parameterized constructor
            Console.WriteLine(pentagon2.calculatePerimeter(pentagon2));
            Console.WriteLine(pentagon2.calculateArea(pentagon2));


            var rectangleCopy = new Rectangle(rectangle2); // copy constructors
            var squareCopy = new Square(square2);          //
            var ellipseCopy = new Ellipse(ellipse2);       //
            var circleCopy = new Circle(circle2);          //
            var pentagonCopy = new Pentagon(pentagon2);    //


            Console.Write("All done, goodbye.\n");




        }
    }
}
