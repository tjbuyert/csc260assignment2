﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Rectangle
    {
        double side;
        double height;
        double defSide = 0;
        double defHeight = 0;

        public Rectangle()
        {
            side = defSide;
            height = defHeight;
            Console.Write("I created a new rectangle with undefined parameters\n");
        }

        public Rectangle(double tempSide, double tempHeight)
        {
            side = tempSide;
            height = tempHeight;
            Console.Write("I created a new rectangle with parameters {0} and {0}!\n", side, height);
        }

        public Rectangle(Rectangle r)
        {
            side = r.side;
            height = r.height;
            Console.Write("I copied a rectangle with paremeters {0} and {0}!\n", side, height);
        }

        public double calculatePerimeter(Rectangle r)
        {
            double perimeter = (r.side * 2) + (r.height * 2);
            Console.Write("The perimeter of the rectangle is {0}\n", perimeter);
            return perimeter;
        }

        public double calculateArea(Rectangle r)
        {
            double area = r.side * r.height;
            Console.Write("The area of the rectangle is {0}\n", area);
            return area;
        }
        ~Rectangle()
        {
            Console.Write("I eliminated a rectangle.\n");
        }

    }
}
