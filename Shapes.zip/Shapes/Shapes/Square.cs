﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Square
    {
        double sideLength;
        double defSide = 0;
        public Square()
        {
            sideLength = defSide;
            Console.Write("I created a new square with undefined side length.\n");
        }
        
        public Square (double side)
        {
            sideLength = side;
            Console.Write("I created a new square with side length {0}!\n", sideLength);
        }

        public Square(Square s)
        {
            sideLength = s.sideLength;
            Console.Write("I copied a square with side length {0}.\n", sideLength);
        }

        public double calculatePerimeter(Square s)
        {
            double perimeter = s.sideLength * 4;
            Console.Write("The perimeter of the square is {0}.\n", perimeter);
            return perimeter;
        }

        public double calculateArea(Square s)
        {
            double squarea = s.sideLength * s.sideLength;
            Console.Write("The area of the square is {0}.\n", squarea);
            return squarea;
        }

        ~Square()
        {
            Console.Write("I vaporized a square!\n");
        }


    }
}
