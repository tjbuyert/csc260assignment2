﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Pentagon
    {
        double sideLength;
        double defSideLength = 0;

        public Pentagon()
        {
            sideLength = defSideLength;
            Console.Write("I created a new pentagon with undefined parameters.\n");
        }

        public Pentagon(double side)
        {
            sideLength = side;
            Console.Write("I created a new pentagon with side length {0}!\n", side);
        }

        public Pentagon(Pentagon p)
        {
            sideLength = p.sideLength;
            Console.Write("I created a new pentagon with side length {0}!\n");
        }

        public double calculatePerimeter(Pentagon p)
        {
            double perimeter = p.sideLength * 5;
            Console.Write("The perimeter of the pentagon is {0}.\n", perimeter);
            return perimeter;
        }

        public double calculateArea(Pentagon p)
        {
            double height = (p.sideLength / 2) / Math.Tan(36);
            double area = height * (p.sideLength / 2) / 2;
            area = area * 10;
            Console.Write("The area of the pentagon is {0}.\n", area);
            return area;
        }
        ~Pentagon()
        {
            Console.Write("I eliminated a pentagon!\n");
        }

    }
}
