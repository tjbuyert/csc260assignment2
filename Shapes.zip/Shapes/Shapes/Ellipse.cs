﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Ellipse
    {
        double semiMajorAxis;
        double semiMinorAxis;
        double DefMajorAxis = 0;
        double DefMinorAxis = 0;
        public Ellipse(){
            semiMajorAxis = DefMajorAxis;
            semiMinorAxis = DefMinorAxis;
            Console.Write("I created a new ellipse with unspecified parameters!\n");
        }

        public Ellipse(double major, double minor)
        {
            semiMajorAxis = major;
            semiMinorAxis = minor;
            Console.Write("I created a new ellipse with major axis '{0}' and minor axis '{0}'!\n", major, minor);
        }

        public Ellipse(Ellipse e)
        {
            semiMajorAxis = e.semiMajorAxis;
            semiMinorAxis = e.semiMinorAxis;
            Console.Write("I created a new ellipse with major axis '{0}' and minor axis '{0}'!\n", e.semiMajorAxis, e.semiMinorAxis);
        }

        public double CalculateArea(Ellipse e)
        {
            double area = Math.PI * e.semiMajorAxis * e.semiMinorAxis;
            Console.Write("The area of the ellipse is {0}\n", area);
            return area;
        }

        public double CalculatePerimeter(Ellipse e)
        {
            double perimeter = 2 * Math.PI * Math.Sqrt((Math.Pow(e.semiMajorAxis, 2) + Math.Pow(e.semiMinorAxis, 2)) / 2);
            Console.Write("The perimeter of the ellipse is {0}\n", perimeter);
            return perimeter;
        }

        ~Ellipse()
        {
            Console.Write("I relieved an Ellipse of its active duties!\n");
        }

    }
}
