﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Circle
    {
        private double radius;
        double DefRadius = 0;
        
        
        public Circle() //default constructor
        {
            radius = DefRadius;
            Console.Write("I created a new circle with an unspecified radius!\n");
        }


        public Circle (double radius) //parameterized constructor
        {
            this.radius = radius;
            Console.Write("I created a new circle with radius of {0}!\n", radius);
        }

        public Circle(Circle c) //copy constructor
        {
            radius = c.radius;
            Console.Write("I copied a circle with a radius of {0}!\n", c.radius);
        }

        public double calculatePerimeter(Circle c)
        {
            double perimeter = c.radius * 2 * Math.PI;
            Console.Write("The perimeter of the circle is {0}.\n", perimeter);
            return perimeter;
        }


        public double calculateArea(Circle c)
        {
            double area = Math.Pow(c.radius, 2);
            Console.Write("The area of this circle is {0}!\n", c.radius);
            return area;
        }
        ~Circle()
        {
            Console.Write("I deconstructed a circle!\n");
        }
    }
}
